## 1. 架构设计
```mermaid
diagram TD
    Frontend[前端应用] --> Backend[后端服务]
    Backend --> Database[数据库]
    Frontend --> Storage[文件存储]
    
    Frontend -- 登录/认证 --> Backend
    Frontend -- CRUD操作 --> Backend
    Backend -- 数据操作 --> Database
    Backend -- 文件上传/下载 --> Storage
```

## 2. 技术描述
- 前端：React@18 + TypeScript + Tailwind CSS@3 + Vite
- 初始化工具：vite-init
- 后端：Express@4 + TypeScript
- 数据库：PostgreSQL
- 认证：JWT
- 文件存储：本地文件系统

## 3. 路由定义
| 路由 | 目的 |
|-------|---------|
| /login | 登录页面 |
| /dashboard | 系统首页 |
| /class-management | 班级管理页面 |
| /exam-management | 考试管理页面 |
| /personnel-management/students | 学员管理页面 |
| /personnel-management/coaches | 教练管理页面 |
| /student/:id | 学员详情页面 |
| /exam/:id | 考试记录详情页面 |
| /class/:id | 班级详情页面 |

## 4. API定义
### 4.1 认证API
| 接口 | 方法 | 功能描述 | 请求体 | 响应 |
|-------|------|---------|--------|--------|
| /api/auth/login | POST | 用户登录 | `{ username: string, password: string }` | `{ token: string, user: { id: number, username: string, role: string } }` |
| /api/auth/refresh | POST | 刷新token | `{ token: string }` | `{ token: string }` |

### 4.2 班级管理API
| 接口 | 方法 | 功能描述 | 请求体 | 响应 |
|-------|------|---------|--------|--------|
| /api/classes | GET | 获取班级列表 | N/A | `{ data: Class[], total: number }` |
| /api/classes | POST | 新增班级 | `ClassCreate` | `Class` |
| /api/classes/:id | GET | 获取班级详情 | N/A | `Class` |
| /api/classes/:id | PUT | 更新班级 | `ClassUpdate` | `Class` |
| /api/classes/:id | DELETE | 删除班级 | N/A | `{ success: boolean }` |

### 4.3 考试管理API
| 接口 | 方法 | 功能描述 | 请求体 | 响应 |
|-------|------|---------|--------|--------|
| /api/exams | GET | 获取考试记录列表 | N/A | `{ data: Exam[], total: number }` |
| /api/exams | POST | 新增考试记录 | `ExamCreate` | `Exam` |
| /api/exams/:id | GET | 获取考试记录详情 | N/A | `Exam` |
| /api/exams/:id | PUT | 更新考试记录 | `ExamUpdate` | `Exam` |
| /api/exams/:id | DELETE | 删除考试记录 | N/A | `{ success: boolean }` |

### 4.4 学员管理API
| 接口 | 方法 | 功能描述 | 请求体 | 响应 |
|-------|------|---------|--------|--------|
| /api/students | GET | 获取学员列表 | N/A | `{ data: Student[], total: number }` |
| /api/students | POST | 新增学员 | `StudentCreate` | `Student` |
| /api/students/:id | GET | 获取学员详情 | N/A | `Student` |
| /api/students/:id | PUT | 更新学员 | `StudentUpdate` | `Student` |
| /api/students/:id | DELETE | 删除学员 | N/A | `{ success: boolean }` |
| /api/students/import | POST | 导入学员 | `FormData` | `{ success: boolean, count: number }` |
| /api/students/export | GET | 导出学员 | N/A | 文件下载 |

### 4.5 教练管理API
| 接口 | 方法 | 功能描述 | 请求体 | 响应 |
|-------|------|---------|--------|--------|
| /api/coaches | GET | 获取教练列表 | N/A | `{ data: Coach[], total: number }` |
| /api/coaches | POST | 新增教练 | `CoachCreate` | `Coach` |
| /api/coaches/:id | GET | 获取教练详情 | N/A | `Coach` |
| /api/coaches/:id | PUT | 更新教练 | `CoachUpdate` | `Coach` |
| /api/coaches/:id | DELETE | 删除教练 | N/A | `{ success: boolean }` |

## 5. 服务器架构图
```mermaid
diagram TD
    Client[客户端] --> API[API层]
    API --> Auth[认证中间件]
    Auth --> Controller[控制器层]
    Controller --> Service[服务层]
    Service --> Repository[数据访问层]
    Repository --> Database[数据库]
    Service --> Storage[文件存储]
```

## 6. 数据模型
### 6.1 数据模型定义
```mermaid
erDiagram
    CLASS ||--o{ STUDENT : has
    CLASS ||--o{ EXAM : relates
    STUDENT ||--o{ EXAM_RECORD : takes
    COACH ||--o{ STUDENT : trains
    COACH ||--o{ EXAM : leads
    
    CLASS {
        int id
        string name
        date start_date
        date end_date
        string status
        int student_count
        string notes
    }
    
    STUDENT {
        int id
        string name
        string gender
        string status
        string phone
        string license_level
        int class_id
        int coach_id
        string inviter
        date payment_date
        date first_exam_date
        date last_exam_date
        string notes
        string photo
        string id_card_type
        string id_card_number
        string nationality
        string ethnicity
        date birth_date
        string province
        string city
        string district
        string address
        string id_card_photo
        string health_cert
        string criminal_record
    }
    
    EXAM {
        int id
        date exam_date
        string location
        int coach_id
        string notes
    }
    
    EXAM_RECORD {
        int id
        int exam_id
        int student_id
        boolean passed
        string failure_reason
    }
    
    COACH {
        int id
        string name
        string contact
        int invited_count
        int training_count
    }
```

### 6.2 数据定义语言
#### 6.2.1 班级表 (classes)
```sql
CREATE TABLE classes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    status VARCHAR(50) NOT NULL DEFAULT '开班',
    student_count INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_classes_status ON classes(status);
CREATE INDEX idx_classes_name ON classes(name);
```

#### 6.2.2 教练表 (coaches)
```sql
CREATE TABLE coaches (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact VARCHAR(255) NOT NULL,
    invited_count INT DEFAULT 0,
    training_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_coaches_name ON coaches(name);
```

#### 6.2.3 学员表 (students)
```sql
CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT '初考',
    phone VARCHAR(20) NOT NULL,
    license_level VARCHAR(50) NOT NULL,
    class_id INT REFERENCES classes(id),
    coach_id INT REFERENCES coaches(id),
    inviter VARCHAR(255),
    payment_date DATE,
    first_exam_date DATE,
    last_exam_date DATE,
    notes TEXT,
    photo VARCHAR(255),
    id_card_type VARCHAR(50),
    id_card_number VARCHAR(50),
    nationality VARCHAR(50),
    ethnicity VARCHAR(50),
    birth_date DATE,
    province VARCHAR(50),
    city VARCHAR(50),
    district VARCHAR(50),
    address VARCHAR(255),
    id_card_photo VARCHAR(255),
    health_cert VARCHAR(255),
    criminal_record VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_students_name ON students(name);
CREATE INDEX idx_students_status ON students(status);
CREATE INDEX idx_students_class_id ON students(class_id);
CREATE INDEX idx_students_coach_id ON students(coach_id);
```

#### 6.2.4 考试表 (exams)
```sql
CREATE TABLE exams (
    id SERIAL PRIMARY KEY,
    exam_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    coach_id INT REFERENCES coaches(id),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_exams_exam_date ON exams(exam_date);
CREATE INDEX idx_exams_coach_id ON exams(coach_id);
```

#### 6.2.5 考试记录表 (exam_records)
```sql
CREATE TABLE exam_records (
    id SERIAL PRIMARY KEY,
    exam_id INT REFERENCES exams(id),
    student_id INT REFERENCES students(id),
    passed BOOLEAN NOT NULL,
    failure_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_exam_records_exam_id ON exam_records(exam_id);
CREATE INDEX idx_exam_records_student_id ON exam_records(student_id);
CREATE INDEX idx_exam_records_passed ON exam_records(passed);
```

### 6.3 初始数据
#### 6.3.1 初始教练数据
```sql
INSERT INTO coaches (name, contact) VALUES
('张教练', '13800138001'),
('李教练', '13900139001'),
('王教练', '13700137001');
```

#### 6.3.2 初始班级数据
```sql
INSERT INTO classes (name, start_date, status) VALUES
('2026年春季班', '2026-03-01', '开班'),
('2026年夏季班', '2026-06-01', '开班');
```