// API工具函数

// 使用模拟数据，不连接到后端服务器
// 这样前端可以在 GitHub Pages 上独立运行

// 模拟数据
const mockStudents = [
  { id: 1, name: '小明', gender: '男', phone: '13800138007', email: 'xiaoming@example.com', address: '北京市朝阳区', photo: null, id_card: '110101199001011234', created_at: new Date(), updated_at: new Date() },
  { id: 2, name: '小红', gender: '女', phone: '13800138008', email: 'xiaohong@example.com', address: '上海市浦东新区', photo: null, id_card: '310101199002022345', created_at: new Date(), updated_at: new Date() },
  { id: 3, name: '小李', gender: '男', phone: '13800138009', email: 'xiaoli@example.com', address: '广州市天河区', photo: null, id_card: '440101199003033456', created_at: new Date(), updated_at: new Date() }
];

const mockCoaches = [
  { id: 1, name: '张三', gender: '男', phone: '13800138001', email: 'zhangsan@example.com', address: '北京市朝阳区', photo: null, id_card: '110101198001011234', speciality: '科目一', created_at: new Date(), updated_at: new Date() },
  { id: 2, name: '李四', gender: '女', phone: '13800138002', email: 'lisi@example.com', address: '上海市浦东新区', photo: null, id_card: '310101198002022345', speciality: '科目二', created_at: new Date(), updated_at: new Date() },
  { id: 3, name: '王五', gender: '男', phone: '13800138003', email: 'wangwu@example.com', address: '广州市天河区', photo: null, id_card: '440101198003033456', speciality: '科目三', created_at: new Date(), updated_at: new Date() }
];

const mockClasses = [
  { id: 1, class_name: '科目一班', coach_id: 1, start_date: new Date('2026-01-01'), end_date: new Date('2026-01-31'), status: '进行中', created_at: new Date(), updated_at: new Date() },
  { id: 2, class_name: '科目二班', coach_id: 2, start_date: new Date('2026-02-01'), end_date: new Date('2026-02-28'), status: '未开始', created_at: new Date(), updated_at: new Date() },
  { id: 3, class_name: '科目三班', coach_id: 3, start_date: new Date('2026-03-01'), end_date: new Date('2026-03-31'), status: '未开始', created_at: new Date(), updated_at: new Date() }
];

const mockExams = [
  { id: 1, exam_name: '科目一考试', exam_date: new Date('2026-01-15'), exam_location_id: 1, exam_type: '理论', status: '进行中', created_at: new Date(), updated_at: new Date() },
  { id: 2, exam_name: '科目二考试', exam_date: new Date('2026-02-20'), exam_location_id: 2, exam_type: '实操', status: '未开始', created_at: new Date(), updated_at: new Date() },
  { id: 3, exam_name: '科目三考试', exam_date: new Date('2026-03-25'), exam_location_id: 3, exam_type: '路考', status: '未开始', created_at: new Date(), updated_at: new Date() }
];

const mockExamLocations = [
  { id: 1, location_name: '北京考场', address: '北京市海淀区', capacity: 100, contact_person: '赵六', contact_phone: '13800138004', created_at: new Date(), updated_at: new Date() },
  { id: 2, location_name: '上海考场', address: '上海市静安区', capacity: 150, contact_person: '孙七', contact_phone: '13800138005', created_at: new Date(), updated_at: new Date() },
  { id: 3, location_name: '广州考场', address: '广州市越秀区', capacity: 120, contact_person: '周八', contact_phone: '13800138006', created_at: new Date(), updated_at: new Date() }
];

const mockExamRecords = [
  { id: 1, student_id: 1, exam_id: 1, score: 95.5, pass_status: '通过', exam_time: new Date('2026-01-15 09:00:00'), notes: '表现优秀', created_at: new Date(), updated_at: new Date() },
  { id: 2, student_id: 2, exam_id: 1, score: 88.0, pass_status: '通过', exam_time: new Date('2026-01-15 10:00:00'), notes: '表现良好', created_at: new Date(), updated_at: new Date() },
  { id: 3, student_id: 3, exam_id: 1, score: 75.0, pass_status: '通过', exam_time: new Date('2026-01-15 11:00:00'), notes: '刚好通过', created_at: new Date(), updated_at: new Date() }
];

// 模拟 API 延迟
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// 学员相关API
export const studentApi = {
  // 获取所有学员
  getStudents: async () => {
    await delay(500); // 模拟网络延迟
    return mockStudents;
  },
  
  // 添加学员
  addStudent: async (student: any) => {
    await delay(500);
    const newStudent = {
      id: mockStudents.length + 1,
      ...student,
      created_at: new Date(),
      updated_at: new Date()
    };
    mockStudents.push(newStudent);
    return { id: newStudent.id, message: 'Student created successfully' };
  },
};

// 班级相关API
export const classApi = {
  getClasses: async () => {
    await delay(500);
    return mockClasses;
  },
  addClass: async (classData: any) => {
    await delay(500);
    const newClass = {
      id: mockClasses.length + 1,
      ...classData,
      created_at: new Date(),
      updated_at: new Date()
    };
    mockClasses.push(newClass);
    return { id: newClass.id, message: 'Class created successfully' };
  },
};

// 教练相关API
export const coachApi = {
  getCoaches: async () => {
    await delay(500);
    return mockCoaches;
  },
  addCoach: async (coach: any) => {
    await delay(500);
    const newCoach = {
      id: mockCoaches.length + 1,
      ...coach,
      created_at: new Date(),
      updated_at: new Date()
    };
    mockCoaches.push(newCoach);
    return { id: newCoach.id, message: 'Coach created successfully' };
  },
};

// 考试相关API
export const examApi = {
  getExams: async () => {
    await delay(500);
    return mockExams;
  },
  addExam: async (exam: any) => {
    await delay(500);
    const newExam = {
      id: mockExams.length + 1,
      ...exam,
      created_at: new Date(),
      updated_at: new Date()
    };
    mockExams.push(newExam);
    return { id: newExam.id, message: 'Exam created successfully' };
  },
};

// 考试地点相关API
export const examLocationApi = {
  getExamLocations: async () => {
    await delay(500);
    return mockExamLocations;
  },
  addExamLocation: async (location: any) => {
    await delay(500);
    const newLocation = {
      id: mockExamLocations.length + 1,
      ...location,
      created_at: new Date(),
      updated_at: new Date()
    };
    mockExamLocations.push(newLocation);
    return { id: newLocation.id, message: 'Exam location created successfully' };
  },
};

// 考试记录相关API
export const examRecordApi = {
  getExamRecords: async () => {
    await delay(500);
    return mockExamRecords;
  },
  addExamRecord: async (record: any) => {
    await delay(500);
    const newRecord = {
      id: mockExamRecords.length + 1,
      ...record,
      created_at: new Date(),
      updated_at: new Date()
    };
    mockExamRecords.push(newRecord);
    return { id: newRecord.id, message: 'Exam record created successfully' };
  },
};
